const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, "data.json");
const CARS = ["Tesla Model S", "BMW X5", "Audi A6"];

// --- tiny JSON "database" (swap for MongoDB/PostgreSQL later) ---
function loadDB() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return { users: [], bookings: [] }; }
}
function saveDB(db) { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret-before-going-live",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 7 * 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function requireLogin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in first." });
  next();
}

// --- auth ---
app.post("/api/register", async (req, res) => {
  const { name = "", email = "", password = "" } = req.body || {};
  const cleanEmail = email.trim().toLowerCase();
  if (name.trim().length < 2) return res.status(400).json({ error: "Enter your full name." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) return res.status(400).json({ error: "Enter a valid email." });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });

  const db = loadDB();
  if (db.users.some(u => u.email === cleanEmail))
    return res.status(409).json({ error: "An account with this email already exists." });

  const user = { id: newId(), name: name.trim(), email: cleanEmail, passwordHash: await bcrypt.hash(password, 10) };
  db.users.push(user);
  saveDB(db);
  req.session.userId = user.id;
  res.json({ name: user.name });
});

app.post("/api/login", async (req, res) => {
  const { email = "", password = "" } = req.body || {};
  const db = loadDB();
  const user = db.users.find(u => u.email === email.trim().toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.passwordHash)))
    return res.status(401).json({ error: "Wrong email or password." });
  req.session.userId = user.id;
  res.json({ name: user.name });
});

app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get("/api/me", requireLogin, (req, res) => {
  const user = loadDB().users.find(u => u.id === req.session.userId);
  if (!user) return res.status(401).json({ error: "Please log in first." });
  res.json({ name: user.name, email: user.email });
});

// --- bookings (only for logged-in users) ---
app.get("/api/bookings", requireLogin, (req, res) => {
  res.json(loadDB().bookings.filter(b => b.userId === req.session.userId));
});

app.post("/api/bookings", requireLogin, (req, res) => {
  const { car, phone = "", date = "" } = req.body || {};
  const today = new Date().toISOString().slice(0, 10);
  if (!CARS.includes(car)) return res.status(400).json({ error: "Unknown car." });
  if (!/^\+?[0-9\s-]{7,15}$/.test(phone.trim())) return res.status(400).json({ error: "Enter a valid phone number." });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date < today) return res.status(400).json({ error: "Choose today or a future date." });

  const db = loadDB();
  const booking = { id: newId(), userId: req.session.userId, car, phone: phone.trim(), date, createdAt: new Date().toISOString() };
  db.bookings.push(booking);
  saveDB(db);
  res.json(booking);
});

app.listen(PORT, () => console.log(`Car Showroom running at http://localhost:${PORT}`));

1. Install Node.js (https://nodejs.org), version 18 or newer.
2. In this folder run:   npm install
3. Start the site:       npm start
4. Open:                 http://localhost:3000/login.html

Before going live: set SESSION_SECRET to a long random value, serve over HTTPS,
and move from data.json to a real database.

document.addEventListener("DOMContentLoaded", async () => {
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");
  const tabLogin = document.getElementById("tabLogin");
  const tabRegister = document.getElementById("tabRegister");

  // Already logged in? Go straight to the showroom.
  try {
    const r = await fetch("/api/me");
    if (r.ok) { location.href = "index.html"; return; }
  } catch (_) {}

  function switchTab(toLogin) {
    loginForm.classList.toggle("hidden", !toLogin);
    registerForm.classList.toggle("hidden", toLogin);
    tabLogin.classList.toggle("active", toLogin);
    tabRegister.classList.toggle("active", !toLogin);
  }
  tabLogin.addEventListener("click", () => switchTab(true));
  tabRegister.addEventListener("click", () => switchTab(false));

 async function send(url, body, errorEl) {
  errorEl.textContent = "";

  if (location.protocol === "file:" || location.port !== "3000") {
    errorEl.textContent =
      "Wrong address. Run npm start, then open http://localhost:3000/login.html";
    return;
  }

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    let data = {};
    try { data = await res.json(); } catch (_) {}

    if (!res.ok) {
      errorEl.textContent = data.error || "Server error (" + res.status + ").";
      return;
    }
    location.href = "index.html";
  } catch (err) {
    errorEl.textContent = "Cannot reach the server. Run npm start and keep the black window open.";
  }
}

  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    send("/api/login", {
      email: document.getElementById("loginEmail").value,
      password: document.getElementById("loginPassword").value
    }, document.getElementById("loginError"));
  });

  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    send("/api/register", {
      name: document.getElementById("regName").value,
      email: document.getElementById("regEmail").value,
      password: document.getElementById("regPassword").value
    }, document.getElementById("registerError"));
  });
});

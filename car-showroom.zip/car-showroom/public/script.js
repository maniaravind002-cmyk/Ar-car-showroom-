document.addEventListener("DOMContentLoaded", async () => {
  const carList = document.getElementById("carList");
  const bookingSection = document.getElementById("bookingSection");
  const confirmationSection = document.getElementById("confirmationSection");
  const form = document.getElementById("bookingForm");
  const carNameInput = document.getElementById("carName");
  const phoneInput = document.getElementById("phone");
  const dateInput = document.getElementById("date");
  const formError = document.getElementById("formError");
  const myBookings = document.getElementById("myBookings");

  const show = el => el.classList.remove("hidden");
  const hide = el => el.classList.add("hidden");

  // --- login guard ---
  let me;
  try {
    const res = await fetch("/api/me");
    if (!res.ok) throw new Error();
    me = await res.json();
  } catch {
    location.href = "login.html";
    return;
  }
  document.getElementById("userName").textContent = me.name;

  document.getElementById("logoutBtn").addEventListener("click", async () => {
    await fetch("/api/logout", { method: "POST" });
    location.href = "login.html";
  });

  // --- date: today or later ---
  const t = new Date();
  dateInput.min = [t.getFullYear(), String(t.getMonth() + 1).padStart(2, "0"), String(t.getDate()).padStart(2, "0")].join("-");

  const fmt = d => new Date(d + "T00:00:00").toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" });

  async function loadBookings() {
    try {
      const res = await fetch("/api/bookings");
      const list = await res.json();
      myBookings.innerHTML = "";
      if (!list.length) {
        myBookings.innerHTML = '<li class="muted">No bookings yet. Choose a car above.</li>';
        return;
      }
      list.sort((a, b) => a.date.localeCompare(b.date)).forEach(b => {
        const li = document.createElement("li");
        li.textContent = `${b.car} – ${fmt(b.date)}`;
        myBookings.appendChild(li);
      });
    } catch {
      myBookings.innerHTML = '<li class="muted">Could not load bookings.</li>';
    }
  }
  loadBookings();

  function clearErrors() {
    ["phone", "date"].forEach(id => {
      document.getElementById(id + "Error").textContent = "";
      document.getElementById(id).classList.remove("invalid");
    });
    formError.textContent = "";
  }
  function setError(input, msg) {
    document.getElementById(input.id + "Error").textContent = msg;
    input.classList.add("invalid");
  }

  document.querySelectorAll(".book-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      form.reset();
      carNameInput.value = btn.closest(".car").dataset.car;
      clearErrors();
      hide(carList); hide(confirmationSection); show(bookingSection);
      phoneInput.focus();
    });
  });

  document.getElementById("closeForm").addEventListener("click", () => {
    hide(bookingSection); show(carList);
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearErrors();
    const phone = phoneInput.value.trim();
    const date = dateInput.value;
    let ok = true;
    if (!/^\+?[0-9\s-]{7,15}$/.test(phone)) { setError(phoneInput, "Enter a valid phone number (7–15 digits)."); ok = false; }
    if (!date) { setError(dateInput, "Choose a booking date."); ok = false; }
    else if (date < dateInput.min) { setError(dateInput, "Choose today or a future date."); ok = false; }
    if (!ok) return;

    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ car: carNameInput.value, phone, date })
      });
      if (res.status === 401) { location.href = "login.html"; return; }
      const data = await res.json();
      if (!res.ok) { formError.textContent = data.error || "Booking failed."; return; }

      document.getElementById("confirmationMessage").textContent =
        `Thank you, ${me.name}. Your ${data.car} is booked for ${fmt(data.date)}. We will contact you on ${data.phone}.`;
      hide(bookingSection); show(confirmationSection);
      loadBookings();
    } catch {
      formError.textContent = "Cannot reach the server. Try again.";
    }
  });

  document.getElementById("newBooking").addEventListener("click", () => {
    hide(confirmationSection); show(carList);
  });
});
